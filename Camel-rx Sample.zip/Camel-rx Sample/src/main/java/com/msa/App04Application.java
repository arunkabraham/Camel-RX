package com.msa;

import java.util.Collection;
import java.util.List;
import java.util.UUID;

import org.apache.camel.CamelContext;
import org.apache.camel.Endpoint;
import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Message;
import org.apache.camel.Producer;
import org.apache.camel.rx.ReactiveCamel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import rx.Observable;
import rx.Subscriber;
import rx.schedulers.Schedulers;

@SpringBootApplication
public class App04Application {
	
	private static final Logger logger = LoggerFactory.getLogger(App04Application.class);
	private static String appId = "RESTApplication02";
	
	private static Exchange exchange1;
	private static Producer producer1;
	private static CamelContext camel;
	
	public static void main(String[] args) throws Exception {
		SpringApplication.run(App04Application.class, args);	
		initialize();
		sendAndReceiveMessage();
		
	}
		
	
		
	public static void initialize() throws Exception{
		
		logger.info("Notice this client requires that the CamelServer is already running!");

        AbstractApplicationContext context = new ClassPathXmlApplicationContext("camel-client.xml");
        camel = context.getBean("camel-client", CamelContext.class);
                 
        // get the endpoint from the camel context
        //Endpoint endpoint1 = camel.getEndpoint("jms:topic:Global Topic");
        Endpoint endpoint1 = camel.getEndpoint("jms:queue:Queue-01");
                
        // create the exchange used for the communication
        // we use the in out pattern for a synchronized exchange where we expect a response
        exchange1 = endpoint1.createExchange(ExchangePattern.InOnly);
                        
        // to send the exchange we need an producer to do it for us
        producer1 = endpoint1.createProducer();
                
        // start the producer so it can operate
        producer1.start();
        
	}
	
	
	
	public static void sendAndReceiveMessage() {			
        try{        
        	int executionCount = 1;        	        
	        String uuid = null;	        
	        for (int index=1; index <= executionCount; index++){        		            
	            exchange1.getIn().setBody("Input Message");	            
	            exchange1.getIn().setHeader("eventType", "msg_custom");           
	            exchange1.getIn().setHeader("JMSCorrelationID", UUID.randomUUID().toString());
	            exchange1.getIn().setHeader("appId", appId);	                  
	            producer1.process(exchange1);	            	        	
	        }		
	        
			ReactiveCamel rx = new ReactiveCamel(camel);						 
			Observable<Message> observable1 = rx.toObservable("activemq:queue:Queue-01?selector=eventType%3D'msg_custom'");
						
			observable1.first().subscribe(new Subscriber<Message>() {
				@Override
				public void onCompleted() {
					logger.info("Completed : !!!!!!!!!!!!!!!! :");														
					observable1.unsubscribeOn(Schedulers.immediate());
					this.unsubscribe();				
				}

				@Override
				public void onError(Throwable arg0) {
					logger.info("Error : !!!!!!!!!!!!!!!! :"+arg0.getMessage());					
				}

				@Override
				public void onNext(Message message) {

					String corId = message.getHeader("JMSCorrelationID").toString();
					String eventType = message.getHeader("eventType").toString();
					logger.info("corIdId: " + corId);
					logger.info("eventType: " + eventType);
					String textMessage = message.getBody().toString();
					
					logger.info("Received... corIdId: " + corId);
					logger.info("Received... Message : " + textMessage);						
										
				}	
				
			});
			  
        }catch(Exception e){
        	logger.error(e.getMessage());
        }		
	}
		
}
