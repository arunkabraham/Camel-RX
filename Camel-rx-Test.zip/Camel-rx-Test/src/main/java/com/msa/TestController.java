package com.msa;

import java.util.UUID;

import org.apache.camel.Exchange;
import org.apache.camel.ExchangePattern;
import org.apache.camel.Message;
import org.apache.camel.rx.ReactiveCamel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.msa.config.CamelConfiguration;

import rx.Observable;
import rx.Subscriber;

@RestController
public class TestController {
	
	private static final Logger logger = LoggerFactory.getLogger(TestController.class);
	private static String appId = "RESTApplication01";

    @RequestMapping("/test")
    public String index() {
    	sendAndReceiveMessage();
        return "Greetings from Spring Boot!";
    }
    
    
    public  void sendAndReceiveMessage() {			
        try{        
        	int executionCount = 1;        	        
	        String uuid = null;
	        
	        Exchange exchange1 = CamelConfiguration.endpoint.createExchange(ExchangePattern.InOnly);
        	
	        for (int index=1; index <= executionCount; index++){        		            
	            exchange1.getIn().setBody("Input Message");	            
	            exchange1.getIn().setHeader("eventType", "msg_custom");           
	            exchange1.getIn().setHeader("JMSCorrelationID", UUID.randomUUID().toString());
	            exchange1.getIn().setHeader("appId", appId);	                  
	            CamelConfiguration.producer.process(exchange1);	            	        	
	        }		
	        
			ReactiveCamel rx = new ReactiveCamel(CamelConfiguration.camelContext);						 
			Observable<Message> observable1 = rx.toObservable("jms:queue:Queue-01?selector=eventType%3D'msg_custom'");
						
			observable1.first().subscribe(new Subscriber<Message>() {
				@Override
				public void onCompleted() {
					logger.info("Completed : !!!!!!!!!!!!!!!! :");														
					//observable1.unsubscribeOn(Schedulers.immediate());
					//this.unsubscribe();				
				}

				@Override
				public void onError(Throwable arg0) {
					logger.info("Error : !!!!!!!!!!!!!!!! :"+arg0.getMessage());					
				}

				@Override
				public void onNext(Message message) {

					String corId = message.getHeader("JMSCorrelationID").toString();
					String eventType = message.getHeader("eventType").toString();
					logger.info("corIdId: " + corId);
					logger.info("eventType: " + eventType);
					String textMessage = message.getBody().toString();
					
					logger.info("Received... corIdId: " + corId);
					logger.info("Received... Message : " + textMessage);		
					
				}			
				
			});
			  
        }catch(Exception e){
        	logger.error(e.getMessage());
        }		
	}

}