package com.msa.config;

import org.apache.camel.CamelContext;
import org.apache.camel.Endpoint;
import org.apache.camel.Producer;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class CamelConfiguration implements ApplicationListener<ContextRefreshedEvent>{
	
	public static Endpoint endpoint;
	public  static Producer producer;
	public  static CamelContext camelContext;	
	
	@Override
	public void onApplicationEvent(ContextRefreshedEvent arg0) {		
		initializeCamelTopic();		
	}
	
	public static void initializeCamelTopic(){
		try {
			//logger.info("Notice this client requires that the CamelServer is already running!");

	        AbstractApplicationContext context = new ClassPathXmlApplicationContext("camel-client.xml");
	        camelContext = context.getBean("camel-client", CamelContext.class);                 

	        // get the endpoint from the camel context
	        endpoint = camelContext.getEndpoint("jms:queue:Queue-01");
	        
	        // to send the exchange we need an producer to do it for us
	        producer = endpoint.createProducer();
	                
	        // start the producer so it can operate
	        producer.start();		
			
		} catch (Exception e) {			
			e.printStackTrace();
		}	
	}
	
}
